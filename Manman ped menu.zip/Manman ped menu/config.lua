Config = {}

Config.Peds = {
    {label = 'kid', model = 'a_m_y_hasjew_01'},
    {label = 'babysam', model = 'BabySamCSF'},
    {label = 'Michael', model = 'player_zero'},
    {label = 'Female Balla', model = 'g_f_y_ballas_01'},
    {label = 'Gangster Male', model = 'g_m_y_ballaeast_01'},
    {label = 'OG Loc Style', model = 'csb_ogloc'},
    -- Add as many as you want!
}
