lib = lib or exports.ox_lib -- fallback if needed

RegisterCommand('pedmenu', function()
    if not lib then
        print("ox_lib is not available.")
        return
    end

    local options = {}

    for i, ped in pairs(Config.Peds) do
        table.insert(options, {
            title = ped.label,
            description = 'Change to this ped model',
            icon = 'user',
            onSelect = function()
                loadPedModel(ped.model)
                SetPlayerModel(PlayerId(), GetHashKey(ped.model))
                SetModelAsNoLongerNeeded(GetHashKey(ped.model))
                lib.notify({title = 'Ped Changed', description = ped.label, type = 'success'})
            end
        })
    end

    lib.registerContext({
        id = 'pedmenu_main',
        title = 'MANMAN PED MENU',
        options = options
    })

    lib.showContext('pedmenu_main')
end, false)

function loadPedModel(model)
    local modelHash = GetHashKey(model)
    RequestModel(modelHash)
    while not HasModelLoaded(modelHash) do
        Wait(50)
    end
end
