fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Manman Development'
description 'Ped Selector with ox_lib'
version '1.0.0'

client_script 'client.lua'
shared_script '@ox_lib/init.lua'
shared_script 'config.lua'
