local isUIOpen = false
local playersList = {}

-- Draw rectangle helper
local function drawRect(x, y, width, height, r, g, b, a)
    DrawRect(x + width / 2, y + height / 2, width, height, r, g, b, a)
end

-- Draw text helper
local function drawText(text, x, y, scale, r, g, b, a, center)
    SetTextFont(4)
    SetTextProportional(0)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextDropshadow(0, 0, 0, 0, 255)
    SetTextEdge(1, 0, 0, 0, 255)
    SetTextDropShadow()
    SetTextOutline()
    if center then
        SetTextCentre(true)
    end
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(x, y)
end

-- Draw the players UI
local function drawPlayersUI()
    local startX, startY = 0.15, 0.2
    local width, height = 0.7, 0.6
    local lineHeight = 0.03
    local maxLines = math.floor(height / lineHeight) - 3

    -- Background
    drawRect(startX, startY, width, height, 30, 30, 30, 220)

    -- Title
    drawText("Players Online ("..#playersList..")", startX + width/2, startY + 0.025, 0.6, 255, 255, 255, 255, true)

    -- Headers
    drawText("ID", startX + 0.1, startY + 0.07, 0.45, 200, 200, 200, 255, false)
    drawText("Name", startX + 0.22, startY + 0.07, 0.45, 200, 200, 200, 255, false)

    -- Player entries
    local linesToShow = math.min(#playersList, maxLines)
    for i = 1, linesToShow do
        local ply = playersList[i]
        local yPos = startY + 0.07 + (i * lineHeight)
        drawText(tostring(ply.id), startX + 0.1, yPos, 0.40, 255, 255, 255, 255, false)
        drawText(ply.name, startX + 0.22, yPos, 0.40, 255, 255, 255, 255, false)
    end

    -- Footer text
    drawText("Press ESC or BACKSPACE to close", startX + width/2, startY + height - 0.04, 0.4, 180, 180, 180, 255, true)
end

-- Open the UI
local function openUI()
    isUIOpen = true
    SetNuiFocus(false, false) -- no NUI focus needed
end

-- Close the UI
local function closeUI()
    isUIOpen = false
end

RegisterNetEvent('tplayers:receivePlayers')
AddEventHandler('tplayers:receivePlayers', function(players)
    playersList = players
    openUI()
end)

-- Main loop to draw UI and handle input
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if isUIOpen then
            drawPlayersUI()

            if IsControlJustPressed(0, 322) or IsControlJustPressed(0, 177) then -- ESC or BACKSPACE
                closeUI()
            end
        else
            Citizen.Wait(500)
        end
    end
end)

-- Command to open the UI
RegisterCommand('tplayers', function()
    TriggerServerEvent('tplayers:requestPlayers')
end, false)
