fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'MANMAN DEVELOPMENT'
description 'TPlayers - Custom UI showing all players and IDs'
version '1.0.0'

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}
