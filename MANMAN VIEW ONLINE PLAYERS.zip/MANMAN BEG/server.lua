ESX = exports['es_extended']:getSharedObject()

RegisterNetEvent('tplayers:requestPlayers')
AddEventHandler('tplayers:requestPlayers', function()
    local src = source
    local players = {}

    for _, playerId in ipairs(GetPlayers()) do
        local xPlayer = ESX.GetPlayerFromId(tonumber(playerId))
        if xPlayer then
            table.insert(players, {
                id = tonumber(playerId),
                name = xPlayer.getName()
            })
        else
            table.insert(players, {
                id = tonumber(playerId),
                name = "Unknown"
            })
        end
    end

    TriggerClientEvent('tplayers:receivePlayers', src, players)
end)
