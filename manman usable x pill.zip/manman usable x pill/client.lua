RegisterNetEvent('manman_drugs:useDrug', function()
    local player = PlayerPedId()

    -- Play pill-taking animation (does NOT remove your weapon)
    RequestAnimDict("mp_suicide")
    while not HasAnimDictLoaded("mp_suicide") do Wait(0) end
    TaskPlayAnim(player, "mp_suicide", "pill", 8.0, -8, -1, 49, 0, false, false, false)

    -- Wait for animation to finish (2.5 seconds)
    Wait(2500)
    ClearPedTasks(player)

    -- Apply drug effects
    SetPedArmour(player, 100)
    SetRunSprintMultiplierForPlayer(PlayerId(), 1.49)

    -- Duration: 90 seconds
    local duration = 90000
    Wait(duration)

    -- Revert speed boost
    SetRunSprintMultiplierForPlayer(PlayerId(), 1.0)
end)
