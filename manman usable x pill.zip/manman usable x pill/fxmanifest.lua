fx_version 'cerulean'
game 'gta5'

author 'MANMAN'
description 'Drug Usage System with Animations & Buffs'
version '1.0.0'

client_script 'client.lua'
server_script 'server.lua'

shared_script '@es_extended/imports.lua' -- If you use ESX, keep this; otherwise remove
