local ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local events = {}       -- eventId -> event data
local signups = {}      -- eventId -> list of player ids
local roles = {}        -- eventId -> playerId -> role ('host', 'mod', 'player')

local function hasGroup(source, requiredGroup)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return false end
    local playerGroup = xPlayer.getGroup()
    return (requiredGroup == 'all') or (playerGroup == requiredGroup)
end

RegisterCommand('createevent', function(source)
    TriggerClientEvent('event:openCreator', source)
end)

RegisterNetEvent('event:createEvent', function(data)
    local src = source
    if not hasGroup(src, data.group) then
        TriggerClientEvent('ox_lib:notify', src, { description = 'You do not have permission to create this event.', type = 'error' })
        return
    end

    local eventId = tostring(math.random(10000, 99999))
    events[eventId] = {
        id = eventId,
        name = data.name,
        desc = data.desc,
        postal = data.postal,
        time = data.time,
        group = data.group,
        max = tonumber(data.max) or Config.DefaultMaxParticipants,
        creator = src,
        coords = data.coords
    }

    signups[eventId] = {}
    roles[eventId] = {}
    roles[eventId][src] = 'host' -- creator is host

    TriggerClientEvent('ox_lib:notify', src, { description = 'Event created successfully.', type = 'success' })
end)

RegisterCommand('event', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return end

    local playerGroup = xPlayer.getGroup()
    local availableEvents = {}

    for id, ev in pairs(events) do
        if ev.group == 'all' or ev.group == playerGroup then
            availableEvents[id] = ev
        end
    end

    TriggerClientEvent('event:showEvents', source, availableEvents)
end)

RegisterNetEvent('event:signup', function(eventId)
    local src = source
    local ev = events[eventId]
    if not ev then
        TriggerClientEvent('ox_lib:notify', src, { description = 'Event does not exist.', type = 'error' })
        return
    end

    if ev.group ~= 'all' then
        if not hasGroup(src, ev.group) then
            TriggerClientEvent('ox_lib:notify', src, { description = 'You cannot join this event.', type = 'error' })
            return
        end
    end

    if not signups[eventId] then signups[eventId] = {} end
    if not roles[eventId] then roles[eventId] = {} end

    for _, pid in ipairs(signups[eventId]) do
        if pid == src then
            TriggerClientEvent('ox_lib:notify', src, { description = 'You are already signed up.', type = 'error' })
            return
        end
    end

    if #signups[eventId] >= ev.max then
        TriggerClientEvent('ox_lib:notify', src, { description = 'Event is full.', type = 'error' })
        return
    end

    table.insert(signups[eventId], src)
    roles[eventId][src] = 'player'

    TriggerClientEvent('ox_lib:notify', src, { description = 'Signed up for event: ' .. ev.name, type = 'success' })

    -- Notify host/mods
    for pid, role in pairs(roles[eventId]) do
        if role == 'host' or role == 'mod' then
            TriggerClientEvent('okokNotify:Alert', pid, "EVENT SIGNUP", GetPlayerName(src) .. " joined " .. ev.name, 5000, 'info')
        end
    end
end)

RegisterCommand('myevent', function(source)
    local src = source
    local foundEventId = nil

    -- Find event where source is host or mod
    for eventId, roleTable in pairs(roles) do
        if roleTable[src] == 'host' or roleTable[src] == 'mod' then
            foundEventId = eventId
            break
        end
    end

    if not foundEventId then
        TriggerClientEvent('ox_lib:notify', src, { description = 'You are not managing any event.', type = 'error' })
        return
    end

    local eventData = events[foundEventId]
    local signupList = signups[foundEventId] or {}

    -- Send data to client to show management menu
    TriggerClientEvent('event:manageEvent', src, eventData, signupList, roles[foundEventId])
end)

RegisterNetEvent('event:kickPlayer', function(eventId, playerId)
    local src = source
    local ev = events[eventId]
    if not ev then return end

    local role = roles[eventId] and roles[eventId][src]
    if role ~= 'host' and role ~= 'mod' then
        TriggerClientEvent('ox_lib:notify', src, { description = 'You do not have permission.', type = 'error' })
        return
    end

    if not signups[eventId] then return end

    local removed = false
    for i, pid in ipairs(signups[eventId]) do
        if pid == playerId then
            table.remove(signups[eventId], i)
            removed = true
            break
        end
    end

    if removed then
        roles[eventId][playerId] = nil
        TriggerClientEvent('ox_lib:notify', src, { description = 'Player kicked.', type = 'success' })
        TriggerClientEvent('ox_lib:notify', playerId, { description = 'You have been kicked from event: ' .. ev.name, type = 'error' })
    else
        TriggerClientEvent('ox_lib:notify', src, { description = 'Player not found in signups.', type = 'error' })
    end
end)

RegisterCommand('startevent', function(source)
    local src = source
    local foundEventId = nil

    -- Find event where source is host or mod
    for eventId, roleTable in pairs(roles) do
        if roleTable[src] == 'host' or roleTable[src] == 'mod' then
            foundEventId = eventId
            break
        end
    end

    if not foundEventId then
        TriggerClientEvent('ox_lib:notify', src, { description = 'You are not managing any event.', type = 'error' })
        return
    end

    local ev = events[foundEventId]
    local signedUpPlayers = signups[foundEventId] or {}

    -- Notify all signed up players that event started
    for _, pid in ipairs(signedUpPlayers) do
        TriggerClientEvent('event:showStartAlert', pid, ev.name, ev.postal)
    end

    TriggerClientEvent('ox_lib:notify', src, { description = 'Event started!', type = 'success' })
end)
