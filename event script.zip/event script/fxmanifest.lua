fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Advanced Event System with Powerful /myevent Management'
author 'MANMAN Development'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_script 'client.lua'
server_script 'server.lua'
