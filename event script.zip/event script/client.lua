local currentEventId = nil

RegisterNetEvent('event:openCreator', function()
    lib.registerContext({
        id = 'event_create_menu',
        title = 'Create Event',
        options = {
            {
                title = 'Set Name',
                icon = '📝',
                onSelect = function()
                    local name = lib.inputDialog('Event Name', { 'Enter name' })
                    if not name then return end

                    local desc = lib.inputDialog('Description', { 'What is this about?' })
                    if not desc then return end

                    local postal = lib.inputDialog('Postal', { 'Enter postal' })
                    if not postal then return end

                    local time = lib.inputDialog('Time', { 'Enter time' })
                    if not time then return end

                    local max = lib.inputDialog('Max Participants', { 'Enter max number' })
                    if not max then return end

                    local group = lib.inputDialog('Permission Group', { 'Enter group (admin, mod, vip, all)' })
                    if not group then return end

                    local coords = GetEntityCoords(PlayerPedId())

                    TriggerServerEvent('event:createEvent', {
                        name = name[1],
                        desc = desc[1],
                        postal = postal[1],
                        time = time[1],
                        max = max[1],
                        group = group[1],
                        coords = coords
                    })
                end
            }
        }
    })
    lib.showContext('event_create_menu')
end)

RegisterNetEvent('event:showEvents', function(events)
    local options = {}

    for id, data in pairs(events) do
        table.insert(options, {
            title = data.name .. ' - ' .. data.time,
            description = 'Click to view details',
            icon = '🎉',
            onSelect = function()
                currentEventId = id
                lib.registerContext({
                    id = 'event_detail_' .. id,
                    title = data.name,
                    options = {
                        { title = 'Description: ' .. data.desc, icon = '📄' },
                        { title = 'Postal: ' .. data.postal, icon = '📍' },
                        { title = 'Time: ' .. data.time, icon = '⏰' },
                        { title = 'Max Players: ' .. data.max, icon = '👥' },
                        { title = 'Permission Group: ' .. data.group, icon = '🔐' },
                        {
                            title = 'Sign Up',
                            icon = '✅',
                            onSelect = function()
                                TriggerServerEvent('event:signup', id)
                            end
                        }
                    }
                })
                lib.showContext('event_detail_' .. id)
            end
        })
    end

    lib.registerContext({
        id = 'event_list_menu',
        title = 'Active Events',
        options = options
    })

    lib.showContext('event_list_menu')
end)

RegisterNetEvent('event:manageEvent', function(eventData, signupList, roleTable)
    local options = {}

    for _, pid in ipairs(signupList) do
        local name = GetPlayerName(pid) or "Unknown"
        local role = roleTable[pid] or 'player'

        table.insert(options, {
            title = name .. " (" .. role .. ")",
            description = "Player ID: " .. pid,
            icon = 'user',
            onSelect = function()
                local subOptions = {
                    {
                        title = 'Kick Player',
                        icon = 'ban',
                        onSelect = function()
                            TriggerServerEvent('event:kickPlayer', eventData.id, pid)
                        end
                    }
                }
                -- Host can assign mod role
                if roleTable[GetPlayerServerId(PlayerId())] == 'host' and role ~= 'host' then
                    table.insert(subOptions, {
                        title = 'Make Moderator',
                        icon = 'user-shield',
                        onSelect = function()
                            TriggerServerEvent('event:assignMod', eventData.id, pid)
                        end
                    })
                end
                lib.registerContext({
                    id = 'manage_player_' .. pid,
                    title = 'Manage Player: ' .. name,
                    options = subOptions
                })
                lib.showContext('manage_player_' .. pid)
            end
        })
    end

    lib.registerContext({
        id = 'manage_event_menu',
        title = 'Manage Event: ' .. eventData.name,
        options = options
    })
    lib.showContext('manage_event_menu')
end)

RegisterNetEvent('event:showStartAlert', function(name, postal)
    local scaleform = RequestScaleformMovie("MP_BIG_MESSAGE_FREEMODE")
    while not HasScaleformMovieLoaded(scaleform) do
        Citizen.Wait(0)
    end

    PushScaleformMovieFunction(scaleform, "SHOW_SHARD_WASTED_MP_MESSAGE")
    PushScaleformMovieFunctionParameterString("~r~EVENT STARTED")
    PushScaleformMovieFunctionParameterString(name .. "\nLocation: " .. postal .. "\nGo now!")
    PopScaleformMovieFunctionVoid()

    local time = 7000
    local start = GetGameTimer()

    while GetGameTimer() - start < time do
        Citizen.Wait(0)
        DrawScaleformMovieFullscreen(scaleform, 255, 255, 255, 255)
    end
end)

-- Optional: assign mod server event (you can add this on server.lua)
RegisterNetEvent('event:assignMod', function(eventId, playerId)
    local src = source
    local ev = events[eventId]
    if not ev then return end
    local role = roles[eventId] and roles[eventId][src]
    if role ~= 'host' then
        TriggerClientEvent('ox_lib:notify', src, { description = 'Only host can assign moderators.', type = 'error' })
        return
    end
    roles[eventId][playerId] = 'mod'
    TriggerClientEvent('ox_lib:notify', src, { description = 'Player assigned as moderator.', type = 'success' })
    TriggerClientEvent('ox_lib:notify', playerId, { description = 'You were made a moderator for event: ' .. ev.name, type = 'info' })
end)
