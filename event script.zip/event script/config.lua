Config = {}

Config.Groups = {
    'admin',
    'mod',
    'vip',
    'all'
}

Config.BlipSprite = 280
Config.BlipColor = 5

Config.DefaultMaxParticipants = 24

-- Example rewards (can be customized per event)
Config.DefaultRewards = {
    money = 5000,
    items = {
        {name = 'bread', amount = 3},
        {name = 'water', amount = 2},
    }
}
